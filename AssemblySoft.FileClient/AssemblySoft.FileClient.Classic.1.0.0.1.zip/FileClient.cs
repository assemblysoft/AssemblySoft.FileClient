﻿using System.IO;
using System.IO.Compression;

namespace SetupLibrary
{
    public class FileClient
    {
        /// <summary>
        /// Copies an existing directory structure into an empty directory structure
        /// </summary>
        /// <param name="sourcePath"></param>
        /// <param name="destinationPath"></param>
        public static void CreateEmptyDirectoryStructureFromDirectory(string sourcePath, string destinationPath)
        {
            foreach (var dirPath in Directory.GetDirectories(sourcePath, "*",
                SearchOption.AllDirectories))
                Directory.CreateDirectory(dirPath.Replace(sourcePath, destinationPath));
        }

        public static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs = false)
        {
            // Get the subdirectories for the specified directory.
            var dir = new DirectoryInfo(sourceDirName);

            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException(
                    "Source directory does not exist or could not be found: "
                    + sourceDirName);
            }

            var dirs = dir.GetDirectories();
            // If the destination directory doesn't exist, create it.
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }

            // Get the files in the directory and copy them to the new location.
            var files = dir.GetFiles();
            foreach (var file in files)
            {
                var temppath = Path.Combine(destDirName, file.Name);
                file.CopyTo(temppath, true);
            }

            // If copying subdirectories, copy them and their contents to new location.
            if (copySubDirs)
            {
                foreach (var subdir in dirs)
                {
                    string temppath = Path.Combine(destDirName, subdir.Name);
                    DirectoryCopy(subdir.FullName, temppath, copySubDirs);
                }
            }
        }


        /// <summary>
        /// Writes text to a text file
        /// </summary>
        /// <param name="path"></param>
        /// <param name="text"></param>
        /// <param name="append"></param>
        //public static void WriteTextToFile(string path, string text, bool append = false)
        //{
        //    if (string.IsNullOrWhiteSpace(text))
        //        return;

        //    var dir = Path.GetDirectoryName(path);
        //    if (dir != null && !Directory.Exists(dir))
        //    {
        //        Directory.CreateDirectory(dir);
        //    }
        //    using (TextWriter writer = new StreamWriter(path, append))
        //    {
        //        writer.WriteLine(text);
        //        writer.Flush();
        //    }
        //}


        /// <summary>
        /// Deletes the file
        /// </summary>
        /// <param name="path"></param>
        public static void DeleteFile(string path)
        {
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }

        public static void UnzipFile(string sourceZipPath, string extractPath)
        {
            ZipFile.ExtractToDirectory(sourceZipPath, extractPath);
        }

        public static void UnzipFiles(string zipFile, string targetDirectory)
        {
            using (var archive = ZipFile.OpenRead(zipFile))
            {
                foreach (var entry in archive.Entries)
                {
                    var dir = Path.GetDirectoryName(entry.FullName);
                    if (dir != null && !Directory.Exists(dir))
                    {
                        Directory.CreateDirectory(dir);
                    }

                    var file = Path.GetFileName(entry.FullName);
                    if (!string.IsNullOrWhiteSpace(file))
                    {
                        entry.ExtractToFile(Path.Combine(targetDirectory, entry.FullName), true);
                    }

                }
            }
        }
    }
}